export const formDatas = [
  [
    "Looking For",
    "Commercial Shop",
    "Commercial Office",
    "Commercial Land",
    "Commercial Building",
    "Industrial Building",
    "Industiral Land",
    "Co-working Space",
    "Private Space",
    "Meeting Room",
  ],
  [
    "Selected city",
    "Delhi",
    "Noida",
    "Hyderebad",
    "Cochin",
    "Mumbai",
    "Banglore",
    "Chennai",
  ],
];
